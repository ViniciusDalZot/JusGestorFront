import * as Yup from "yup";

Yup.setLocale({
  mixed: {
    required: "Preenchimento obrigatório",
  },
});

export default Yup;